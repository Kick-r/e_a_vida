#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

int victory(int vet[16]){
	int p = 0;
	for(int x = 0; x < 16; x++){
		if(vet[x] == -1){
			p = p + 1;
		}
	}
	printf("%d",p);
	if(p == 16){
		return  1;
	}
	else{
		return 0;
	}
}

main(){
	//-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -,1 -1, -1, -1, -1
	//
    int vet[16] = {1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8};
    FILE *file;
    int g;
    
    while(g != 1){
	    file = fopen("conector.txt", "r");
	    int x, y, z;
	    fscanf(file, "%i %i", &x, &y);
	    for(int i = 0; i < 4; i++){
			fscanf(file, "%i", &z);
		}
		fclose(file);
		if (z == 1){
			vet[x] = -1;
			vet[y] = -1;
		}
		int g = victory(vet);
		if(g == 1){
			file = fopen("final.txt", "w");
			fprintf(file, "%d", g);
	    	fclose(file);
	    	exit(0);
		}
		Sleep(200);
	}
}

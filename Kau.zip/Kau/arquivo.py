
#importaçõesS
import pygame, sys
from os import startfile
from pygame.locals import QUIT
import suporte
import random
from time import sleep

startfile("Loop.exe")

#cofig padrão
pygame.init()
fundo = pygame.display.set_mode((400, 500))
pygame.display.set_caption('O Mistério dos Números Perdidos')


#criação de variáveis
black = (0, 0, 0)
white = (255, 255, 255)
verde = (0, 255, 0)
vermelho = (255, 0, 0)
text_base = ['√25', '5', '8 + 3', '11',
            '5 * 6', '30', '7 * 2', '14',
            '√49', '7', '6 + 6', '12',
            '9 +7', '16', '11 + 4', '15']
text_random = random.sample(text_base, len(text_base))
text = text_random
cor = [black, black, black, black,
       black, black, black, black,
       black, black, black, black,
       black, black, black, black]
font = pygame.font.SysFont(None, 24)
fonte = pygame.font.SysFont(None, 36)

cont_init = 0
cont_play = 0
anim = 0
line_3 = 0
line_5 = 0
n1, n2 = 0, 0
t1, t2 = 0, 0
para = 0
armazena = list()

def procura(base, ran):
    for x in range(0, 16):
        if ran == base[x]:
            return x

button_Collid = [pygame.Rect([63, 332, 80, 55]),
                 pygame.Rect([257, 332, 80, 55]),
                 pygame.Rect([190, 400, 30, 30])]



#bloco loop
while True:
    para = suporte.line_5()
    number = ['1', '2', '3', '4',
          '5', '6', '7', '8',
          '9',  '10', '11', '12',
          '13', '14', '15', '16']
    #config padrão
    for event in pygame.event.get():
        if event.type == QUIT:
            suporte.sair()
            suporte.final()
            pygame.quit()
            sys.exit()
            
    fundo.fill((255, 255, 255))
    if para == 0:
        suporte.blocks(fundo, black)
        suporte.escrever(fundo, text, cor)
    #começo da área de eventos
    cont_init, cor, text = suporte.inity(cont_init,  cor, text, white, black, number)
    
    press = pygame.mouse.get_pressed()[0]
    if press:
        pos = pygame.mouse.get_pos()
        mouse = pygame.Rect(pos, (10, 10))
        if mouse.colliderect(button_Collid[0]):
            n1 += 1
            if n1 > 16:
                n1 = 0
            if n1 < 0:
                n1 = 16
        if mouse.colliderect(button_Collid[1]):
            n2 += 1
            if n2 > 16:
                n2 = 0
            if n2 < 0:
                n2 = 16
        if mouse.colliderect(button_Collid[2]):
            n1 -= 1
            n2 -= 1
            t1 = procura(text_base, text_random[n1])
            t2 = procura(text_base, text_random[n2])
            suporte.line_1(t1, t2)
            print(t1, t2)
            sleep(0.1)
            startfile("Start.exe")
            sleep(0.3)
            line_3 = suporte.line_3()
            print(line_3)
            anim = 1

    for x in armazena:
        cor[x] = black
        
    if anim == 1:
        if cont_play < 50:
            text[n1] = text_random[n1]
            text[n2] = text_random[n2]
            if line_3 == 1:
                cor[n1] = verde
                cor[n2] = verde
            else:
                cor[n1] = vermelho
                cor[n2] = vermelho
        else:
            if line_3 == 1:
                armazena.append(n1)
                armazena.append(n2)
                
            cor[n1] = black
            cor[n2] = black
            anim = 0
            n1 = 0
            n2 = 0
            cont_play = 0
        cont_play += 1

        
    #fim da área dde eventos
        
    #Controles
    if para == 0:              
        button = [font.render(f'{n1}', True, black), font.render(f'{n2}', True, black)]
        fundo.blit(button[0], (100, 350))
        fundo.blit(button[1], (295, 350))
        pygame.draw.rect(fundo, black, [63, 332, 80, 55], True)
        pygame.draw.rect(fundo, black, [257, 332, 80, 55], True)
        pygame.draw.rect(fundo, (255, 0, 0), [190, 400, 30, 30])
    else:
        pot1 = font.render('Obrigado por ter', True, black)
        pot2 = fonte.render('JOGADO!!', True, black)
        fundo.blit(pot1, (130, 200))
        fundo.blit(pot2, (130, 250))
        suporte.final()
        
    pygame.display.update()
    sleep(0.2)
    
    

def line_3():
    with open("conector.txt", "r") as arquivo:
        linha = arquivo.readlines()
        linha[2] = linha[2].replace('\n', '')
        linha[2] = linha[2].strip()
        x = int(linha[2])
        return x
    
def line_1(x, y):
    arquivo = open("conector.txt", "r")
    linha = arquivo.readlines()
    arquivo.close
    conteudo = list()
    text = f'{x} {y} \n'
    conteudo.append(text)
    conteudo.append(text)
    conteudo.append(linha[2])
    conteudo.append(linha[3])
    conteudo.append(linha[4])
    arquivo = open("conector.txt", "w")
    arquivo.writelines(conteudo)
    arquivo.close()

def line_5():
    with open("conector.txt", "r") as arquivo:
        linha = arquivo.readlines()
        linha[4] = linha[4].replace('\n', '')
        linha[4] = linha[4].strip()
        x = int(linha[2])
        return x
